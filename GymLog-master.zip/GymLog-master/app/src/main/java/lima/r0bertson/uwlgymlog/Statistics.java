package lima.r0bertson.uwlgymlog;


public class Statistics {
    private int load;
    private String date;

    public Statistics (int load, String date){
        this.load = load;
        this.date = date;
    }

    public int getLoad() {
        return load;
    }


}
